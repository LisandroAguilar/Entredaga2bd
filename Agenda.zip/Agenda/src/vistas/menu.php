<!DOCTYPE html>
<html lang="es-MX">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <title>Menú Principal</title>
    <link rel="stylesheet" href="./src/controlador/css/style.css">
</head>

<body>
    <h2>Menu Principal</h2>
    <br><br>
    <?php
        require("../../src/modelo/conexion.php");
        $cveusuario = $_POST["usuario_txt"];
        $pass1 = $_POST["pass_txt"];

        $sql = "SELECT * FROM usuario WHERE usuario='$cveusuario' and pass='$pass1'";
        $query = $conn->prepare($sql);
        $query->execute();

        if ($results = $query->fetchAll(PDO::FETCH_OBJ)) {
            echo '<script>
                Swal.fire({
                icon: "success",
                title:"Usuario aceptado",
                text: "Registro correcto",
                showConfirmButton: true,
                confirmButtonText: "Aceptar"
            }) </script>';

            //INICIO DE SESION
            session_start();

            //DECLARO VARIABLES DE SESION
            $_SESSION["autentificado"] = true;
            $_SESSION["usuario"] = $_POST["usuario_txt"];

            //CERRAR BASE DE DATOS
            $sql = null;
            $conn = null;

        } else {
            //CERRAR BASE DE DATOS
            $sql = null;
            $conn = null;

            header("Location: ../../index.php?error=si");
        }
    ?>
    Bienvenido:
    <?php echo $_SESSION["usuario"]; ?>
    <br><br><br>
    <a href="../../index.php">
        <input type="submit" value="Cerrar Sesión">
    </a>
</body>

</html>