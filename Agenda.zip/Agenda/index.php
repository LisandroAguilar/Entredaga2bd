<?php
require("./src/modelo/conexion.php");
?>
<!DOCTYPE html>
<html lang="es-MX">

<head>

    <title>Agenda Lisandro</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Bootstrap v5.1.3 CDNs -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="shortcut icon" href="https://fca.unach.mx/images/logo_facultad.png">
    <!-- CSS File -->
    <link rel="stylesheet" href="style.css">

</head>

<body>

  <div class="px-4 py-5 px-md-5 text-center text-lg-start" style="background-color: hsl(0, 0%, 96%)">
    <div class="container">
      <div class="row gx-lg-5 align-items-center">
        <div class="col-lg-6 mb-5 mb-lg-0">
          <h1 class="my-5 display-3 fw-bold ls-tight">
            Bienvenido <br />
            <span class="text-primary">La mejor base de datos</span>
          </h1>
          <img src="https://upload.wikimedia.org/wikipedia/commons/3/33/Escudo_unach.png" alt="Logo de la UNACH" width="250px" height="200px">
        </div>
        <div class="col-lg-6 mb-5 mb-lg-0">
          <div class="card">
            <div class="card-body py-5 px-md-5">
              <form class="needs-validation" form name="agenda_fmt" action="./src/vistas/menu.php" method="POST" enctype="application/x-www-form-urlencoded">
              
              <div>
                  <label class="form-label">Dirección de correo electronico</label>
                  <input class="form-control" type="text" name="usuario_txt" id="email">
              </div>
                <div>
                  <label class="form-label">Constraseña</label>
                  <input class="form-control" type="password" id="password" name="pass_txt">
              </div>
                <input class="btn btn-success w-100" type="submit" value="Iniciar sesion">
                
                <?php
        error_reporting(E_ALL ^ E_NOTICE ^ E_WARNING);
        if ($_GET["error"] == "si") {
            echo '<script>
                    Swal.fire({
                    icon: "error",title:"Usuario incorrecto",
                    text: "Registro incorrecto",showConfirmButton: true,confirmButtonText: "Aceptar"
                    });
                </script>';
        } else {
            echo "Introduce tus datos";
        }
        ?>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</body>

</html>
